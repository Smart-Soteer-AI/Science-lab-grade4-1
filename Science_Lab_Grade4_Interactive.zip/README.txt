GRADE 4 VIRTUAL SCIENCE LAB — INTERACTIVE VERSION

Contents:
- index.html: standalone website. All CSS and JavaScript are included.
- No external libraries, images, accounts, or server are required.

Install on GitHub Pages:
1. Open your repository: Smart-Soteer-AI/Science-lab-grade4-1
2. Open the existing index.html file.
3. Choose Edit (pencil) and replace all file contents with this index.html content.
   If the mobile editor is difficult, upload this index.html from the repository's Add file > Upload files flow and commit the change.
4. Commit changes to the main branch.
5. Wait about 1–3 minutes, then refresh:
   https://smart-soteer-ai.github.io/Science-lab-grade4-1/

Features:
- Eight Grade 4 science chapters
- Interactive simulations for habitats, butterfly life cycle, plant growth, shadows, sound, wind, elastic force, and soil drainage
- Tool tray and workbench, step-by-step guides, quiz, and observation notes
- Mobile-friendly layout

Note: simulations are simplified educational models, not real lab measurements.
